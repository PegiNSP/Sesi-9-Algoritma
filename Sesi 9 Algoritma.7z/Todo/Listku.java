import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Listku {
    
    public static void main(String[] args) {
        
        Queue<String> todoQueue = new LinkedList<>();
        Scanner input = new Scanner(System.in);
        
        // add kegiatan kedalam antrian
        todoQueue.add("Bangun tidur");
        todoQueue.add("Mandi dan gosok gigi");
        todoQueue.add("Berpakaian");
        todoQueue.add("Sarapan pagi");
        todoQueue.add("Berangkat kerja");
        todoQueue.add("Makan siang");
        todoQueue.add("Pulang kerja");
        todoQueue.add("Makan malam");
        todoQueue.add("Mengerjakan kegiatan lain");
        todoQueue.add("bersih bersih dan cuci muka");
        todoQueue.add("Tidur");
        
        // Menampilkan semua kegiatan pada antrian
        System.out.println("Kegiatan harian:");
        for (String todo : todoQueue) {
            System.out.println(todo);
        }
        
        // Menambahkan kegiatan baru pada antrian
        System.out.println("\nMasukkan kegiatan baru (atau tekan enter untuk keluar):");
        String newTodo = input.nextLine();
        while (!newTodo.isEmpty()) {
            todoQueue.add(newTodo);
            System.out.println("\nKegiatan baru, berhasil ditambahkan!");
            System.out.println("\nMasukkan kegiatan baru (atau tekan enter untuk keluar):");
            newTodo = input.nextLine();
        }
        
        // Menampilkan seluruh kegiatan pada antrian setelah penambahan kegiatan baru
        System.out.println("\nKegiatan harian (setelah ditambahkan rutinitas baru):");
        for (String todo : todoQueue) {
            System.out.println(todo);
        }
        
        // Menghapus Kegiatan dari antrian
        System.out.println("\nKegiatan pertama (" + todoQueue.peek() + ") telah selesai dilakukan.");
        todoQueue.poll();
        
        // Menampilkan seluruh kegiatan pada antrian setelah penghapusan kegiatan pertama
        System.out.println("\nRutinitas harian (setelah menghapus rutinitas pertama):");
        for (String todo : todoQueue) {
            System.out.println(todo);
        }
    }
}
